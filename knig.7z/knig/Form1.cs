﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace knig
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Внимание во избежание ошибок не используйте символов которые не содержаться в книге");
        }
        string text;
      

        private void button1_Click(object sender, EventArgs e)
        {
            text = System.IO.File.ReadAllText("kluch.txt");                    
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int flag = 0;
            int res;

            if (text!=null)
            {
                
                if (norm.Text != "")
                {
                    shifr.Text = "";
                    for (int i = 0; i < norm.Text.Length; i++)
                    {
                        int sim = 0;
                        int str = 0;
                        int pg = 0;
                        int kolv = 0;
                        
                        for (int kl = 0; kl < text.Length; kl++)
                        {
                            if (text[kl] == norm.Text[i])
                            {
                                kolv++;
                                
                            }
                        }  
                            Random rand = new Random();
                            res = rand.Next(1, kolv);
                            kolv = 0;
                            int p = 0;
                            while (kolv != res)
                            {
                               
                                if (text[p] == norm.Text[i])
                                {
                                    kolv++;
                                }
                                p++;
                                sim++;
                            }
                            if (sim >= 50)
                            {
                                str = sim / 50;
                                sim = sim - (str * 50);
                            }
                            if (str >= 30)
                            {
                                pg = str / 30;
                                str = str - (pg * 30);
                            }
                            shifr.Text += Convert.ToString(pg + 1);
                            shifr.Text += Convert.ToString('.');
                            shifr.Text += Convert.ToString(str + 1);
                            shifr.Text += Convert.ToString('.');
                            shifr.Text += Convert.ToString(sim + 1);
                            shifr.Text += Convert.ToString('.');
                        
                    }
                    flag = 1;
                }

                if (shifr.Text != "" && flag == 0)
                {
                    int sim = 0;
                    int str = 0;
                    int pg = 0;
                    int flags = 1;
                    string bufer = "";
                    string n = "";
                    for (int i = 0; i < shifr.Text.Length; i++)
                    {
                        if (shifr.Text[i] != '.')
                        {
                            bufer += shifr.Text[i];
                        }
                        else
                        {
                            if (flags == 1)
                            {
                                pg = Convert.ToInt32(bufer) - 1;
                                bufer = "";
                                flags = 2;
                            }
                            else
                            {
                                if (flags == 2)
                                {
                                    str = Convert.ToInt32(bufer) - 1  + (pg *30);
                                    bufer = "";
                                    flags = 3;
                                }
                                else
                                {
                                    if (flags == 3)
                                    {
                                        sim = Convert.ToInt32(bufer) - 2 + (str * 50);
                                        bufer = "";
                                        flags = 1;
                                        n += text[sim];
                                    }
                                }
                            }
                        }
                    }
                    norm.Text = n;
                }

                    if (shifr.Text == "" && norm.Text == "")
                   {
                        MessageBox.Show("Введите текст или шифр");
                    }
                
                
            }
            else
            {
                MessageBox.Show("Нет ключа");
            }
        }    
    }
}
